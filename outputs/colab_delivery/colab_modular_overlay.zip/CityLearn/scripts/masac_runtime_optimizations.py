"""Runtime optimizations for the external MARL MASAC backend.

The upstream MASAC implementation is kept in ``external/MARL``.  This module
patches its learner class at runtime so the project remains reproducible
without committing local-only changes inside the external submodule.
"""

from __future__ import annotations

import os
from typing import Any

# The external MASAC runner (external/MARL) imports ``matplotlib.pyplot`` at module
# import time and calls ``plt.savefig`` at the end of ``run()``.  Colab launches each
# job as a headless ``Popen`` subprocess with no display, where an interactive backend
# raises and silently discards the whole finalization (no checkpoint, no results.json).
# Forcing the Agg file backend here (imported before ``runner_msac``) prevents that.
os.environ.setdefault("MPLBACKEND", "Agg")
try:
    import matplotlib

    matplotlib.use("Agg", force=True)
except Exception:
    pass

import torch
import torch.nn.functional as F


PATCH_VERSION = "citylearn_masac_runtime_v1"


def _device_for(args: Any) -> torch.device:
    if bool(getattr(args, "cuda", False)) and torch.cuda.is_available():
        return torch.device("cuda:0")

    return torch.device("cpu")


def _move_tensor(value: Any, *, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
    if torch.is_tensor(value):
        return value.to(device=device, dtype=dtype, non_blocking=True)

    return torch.as_tensor(value, dtype=dtype, device=device)


def _prepare_batch(self: Any, batch: dict[str, Any]) -> dict[str, torch.Tensor]:
    """Convert a sampled replay batch once, with CUDA fallback for 8GB GPUs."""

    target_device = _device_for(self.args)
    mode = str(getattr(self.args, "citylearn_preload_batch_device", "auto")).lower()
    prefer_cuda = target_device.type == "cuda" and mode != "cpu"
    device = target_device if prefer_cuda else torch.device("cpu")

    def convert(convert_device: torch.device) -> dict[str, torch.Tensor]:
        converted: dict[str, torch.Tensor] = {}
        for key, value in batch.items():
            dtype = torch.long if key == "u" else torch.float32
            converted[key] = _move_tensor(value, dtype=dtype, device=convert_device)
        return converted

    if device.type == "cuda":
        try:
            prepared = convert(device)
            self._citylearn_batch_device = "cuda"
            return prepared
        except RuntimeError as exc:
            if "out of memory" not in str(exc).lower() or mode == "cuda":
                raise
            torch.cuda.empty_cache()

    prepared = convert(torch.device("cpu"))
    self._citylearn_batch_device = "cpu"
    return prepared


def _ensure_device(self: Any, value: torch.Tensor) -> torch.Tensor:
    device = _device_for(self.args)
    if value.device == device:
        return value

    return value.to(device=device, non_blocking=True)


def _agent_identity(self: Any, episode_num: int, like: torch.Tensor) -> torch.Tensor:
    key = (str(like.device), str(like.dtype), int(self.args.n_agents), int(episode_num))
    cache = getattr(self, "_citylearn_agent_identity_cache", None)
    if cache is None:
        cache = {}
        self._citylearn_agent_identity_cache = cache

    if key not in cache:
        cache[key] = torch.eye(
            self.args.n_agents,
            device=like.device,
            dtype=like.dtype,
        ).unsqueeze(0).expand(episode_num, -1, -1)

    return cache[key]


def _get_inputs(self: Any, batch: dict[str, torch.Tensor], transition_idx: int):
    obs = batch["o"][:, transition_idx]
    obs_next = batch["o_next"][:, transition_idx]
    u_onehot = batch["u_onehot"]
    episode_num = obs.shape[0]

    inputs = [obs]
    inputs_next = [obs_next]

    if self.args.last_action:
        if transition_idx == 0:
            inputs.append(torch.zeros_like(u_onehot[:, transition_idx]))
        else:
            inputs.append(u_onehot[:, transition_idx - 1])
        inputs_next.append(u_onehot[:, transition_idx])

    if self.args.reuse_network:
        agent_id = _agent_identity(self, episode_num, obs)
        inputs.append(agent_id)
        inputs_next.append(agent_id)

    inputs = torch.cat([x.reshape(episode_num * self.args.n_agents, -1) for x in inputs], dim=1)
    inputs_next = torch.cat([x.reshape(episode_num * self.args.n_agents, -1) for x in inputs_next], dim=1)

    if bool(getattr(self.args, "cuda", False)):
        inputs = _ensure_device(self, inputs)
        inputs_next = _ensure_device(self, inputs_next)

    return inputs, inputs_next


def _init_hidden(self: Any, episode_num: int) -> None:
    device = _device_for(self.args)
    shape = (episode_num, self.n_agents, self.args.rnn_hidden_dim)
    self.eval_hidden = torch.zeros(shape, device=device)
    self.target_hidden = torch.zeros(shape, device=device)
    self.eval_hidden_2 = torch.zeros(shape, device=device)
    self.target_hidden_2 = torch.zeros(shape, device=device)
    self.policy_hidden = torch.zeros(shape, device=device)


def _get_q_values(self: Any, batch: dict[str, torch.Tensor], max_episode_len: int):
    episode_num = batch["o"].shape[0]
    q_evals, q_targets = [], []
    for transition_idx in range(max_episode_len):
        inputs, inputs_next = self._get_inputs(batch, transition_idx)
        q_eval, self.eval_hidden = self.eval_rnn(inputs, self.eval_hidden)
        q_target, self.target_hidden = self.target_rnn(inputs_next, self.target_hidden)
        q_evals.append(q_eval.view(episode_num, self.n_agents, -1))
        q_targets.append(q_target.view(episode_num, self.n_agents, -1))

    return torch.stack(q_evals, dim=1), torch.stack(q_targets, dim=1)


def _get_q_values_2(self: Any, batch: dict[str, torch.Tensor], max_episode_len: int):
    episode_num = batch["o"].shape[0]
    q_evals, q_targets = [], []
    for transition_idx in range(max_episode_len):
        inputs, inputs_next = self._get_inputs(batch, transition_idx)
        q_eval, self.eval_hidden_2 = self.eval_rnn_2(inputs, self.eval_hidden_2)
        q_target, self.target_hidden_2 = self.target_rnn_2(inputs_next, self.target_hidden_2)
        q_evals.append(q_eval.view(episode_num, self.n_agents, -1))
        q_targets.append(q_target.view(episode_num, self.n_agents, -1))

    return torch.stack(q_evals, dim=1), torch.stack(q_targets, dim=1)


def _train_actor(self: Any, batch: dict[str, Any], max_episode_len: int, actor_sample_times=None):
    batch = _prepare_batch(self, batch)
    episode_num = batch["o"].shape[0]
    self.init_hidden(episode_num)

    s = _ensure_device(self, batch["s"]) if self.args.cuda else batch["s"]
    terminated = batch["terminated"]
    mask = 1 - batch["padded"].float()
    mask[:, 1:] = mask[:, 1:] * (1 - terminated[:, :-1])
    mask = mask.repeat(1, 1, self.n_agents)
    actions = _ensure_device(self, batch["u"]) if self.args.cuda else batch["u"]
    avail_u = _ensure_device(self, batch["avail_u"]) if self.args.cuda else batch["avail_u"]
    mask = _ensure_device(self, mask) if self.args.cuda else mask

    q_evals = []
    actions_prob = []
    actions_logprobs = []
    for transition_idx in range(max_episode_len):
        inputs, _ = self._get_inputs(batch, transition_idx)
        q_eval, self.eval_hidden = self.eval_rnn(inputs, self.eval_hidden)
        q_eval = q_eval.view(episode_num, self.n_agents, -1)
        q_evals.append(q_eval)

        agent_outs, self.policy_hidden = self.agent.policy(inputs, self.policy_hidden)
        avail_actions = avail_u[:, transition_idx]
        reshaped_avail_actions = avail_actions.reshape(episode_num * self.n_agents, -1)
        agent_outs[reshaped_avail_actions == 0] = -1e11
        agent_outs = F.softmax(agent_outs, dim=1).view(episode_num, self.n_agents, -1)
        actions_prob.append(agent_outs)
        actions_logprobs.append(torch.log(agent_outs + (agent_outs == 0.0).float() * 1e-8))

    del actions
    q_vals = torch.stack(q_evals, dim=1)
    actions_prob = torch.stack(actions_prob, dim=1)
    log_prob_pi = torch.stack(actions_logprobs, dim=1)

    q_i_mean_negi_mean = torch.sum(actions_prob * (self.alpha * log_prob_pi - q_vals), dim=-1)
    q_i_mean_negi_mean = self.eval_qmix_net(q_i_mean_negi_mean, s)
    q_i_mean_negi_mean = q_i_mean_negi_mean.repeat(repeats=(1, 1, self.n_agents))
    policy_loss = (q_i_mean_negi_mean * mask).sum() / mask.sum()

    self.policy_optimiser.zero_grad()
    policy_loss.backward()
    torch.nn.utils.clip_grad_norm_(self.policy_params, self.args.grad_norm_clip)
    self.policy_optimiser.step()
    self.soft_update()


def _train_critic(self: Any, batch: dict[str, Any], max_episode_len: int, train_step: int, epsilon=None):
    batch = _prepare_batch(self, batch)
    episode_num = batch["o"].shape[0]
    self.init_hidden(episode_num)

    s = batch["s"]
    s_next = batch["s_next"]
    u = batch["u"]
    r = batch["r"]
    terminated = batch["terminated"]
    mask = 1 - batch["padded"].float()
    mask[:, 1:] = mask[:, 1:] * (1 - terminated[:, :-1])
    mask = mask.repeat(1, 1, self.n_agents)
    r = 10.0 * (r - r.mean()) / (r.std() + 1.0e-6)

    q_evals, q_targets = self.get_q_values(batch, max_episode_len)
    q_evals_2, q_targets_2 = self.get_q_values_2(batch, max_episode_len)

    if self.args.cuda:
        s = _ensure_device(self, s)
        s_next = _ensure_device(self, s_next)
        u = _ensure_device(self, u)
        r = _ensure_device(self, r)
        terminated = _ensure_device(self, terminated)
        mask = _ensure_device(self, mask)
        avail_u = _ensure_device(self, batch["avail_u"])
    else:
        avail_u = batch["avail_u"]

    q_evals = torch.gather(q_evals, dim=3, index=u).squeeze(3)
    q_evals_2 = torch.gather(q_evals_2, dim=3, index=u).squeeze(3)

    actions_prob = []
    actions_logprobs = []
    for transition_idx in range(max_episode_len):
        _, inputs_next = self._get_inputs(batch, transition_idx)
        agent_outs, self.policy_hidden = self.agent.policy(inputs_next, self.policy_hidden)
        avail_actions = avail_u[:, transition_idx]
        reshaped_avail_actions = avail_actions.reshape(episode_num * self.n_agents, -1)
        agent_outs[reshaped_avail_actions == 0] = -1e11
        agent_outs = F.softmax(agent_outs, dim=1).view(episode_num, self.n_agents, -1)
        actions_prob.append(agent_outs)
        actions_logprobs.append(torch.log(agent_outs + (agent_outs == 0.0).float() * 1e-8))

    actions_prob = torch.stack(actions_prob, dim=1)
    log_prob_pi = torch.stack(actions_logprobs, dim=1)

    target_entropy = -1.0 * self.n_actions
    if self.args.auto_entropy is True:
        alpha_loss = (
            torch.sum(
                actions_prob.detach() * (-self.log_alpha * (log_prob_pi + target_entropy).detach()),
                dim=-1,
            )
            * mask
        ).sum() / mask.sum()
        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()
        self.alpha = self.log_alpha.exp()
    else:
        self.alpha = 1.0

    q_targets_sample = torch.sum(actions_prob * (q_targets - self.alpha * log_prob_pi), dim=-1).view(
        episode_num,
        max_episode_len,
        -1,
    ).detach()
    q_targets_sample_2 = torch.sum(actions_prob * (q_targets_2 - self.alpha * log_prob_pi), dim=-1).view(
        episode_num,
        max_episode_len,
        -1,
    ).detach()

    q_total_eval = self.eval_qmix_net(q_evals, s)
    q_total_target = self.target_qmix_net(q_targets_sample, s_next)
    q_total_eval_2 = self.eval_qmix_net_2(q_evals_2, s)
    q_total_target_2 = self.target_qmix_net_2(q_targets_sample_2, s_next)
    q_total_target = torch.min(q_total_target, q_total_target_2)
    targets = r + self.args.gamma * q_total_target * (1 - terminated)

    loss = ((mask * (q_total_eval - targets.detach())) ** 2).sum() / mask.sum()
    self.optimizer.zero_grad()
    loss.backward()
    torch.nn.utils.clip_grad_norm_(self.eval_parameters, self.args.grad_norm_clip)
    self.optimizer.step()

    loss_2 = ((mask * (q_total_eval_2 - targets.detach())) ** 2).sum() / mask.sum()
    self.optimizer_2.zero_grad()
    loss_2.backward()
    torch.nn.utils.clip_grad_norm_(self.eval_parameters_2, self.args.grad_norm_clip)
    self.optimizer_2.step()

    # Persist a resumable checkpoint frequently (default: every QMIX update) so an
    # interruption near the end of training never discards trained weights. With
    # critic_train_steps=1 on CityLearn, train_step increments once per epoch.
    save_every = int(getattr(self.args, "citylearn_masac_save_every_steps", 0) or 0)
    if save_every <= 0:
        save_every = 10000
    if train_step % save_every == 0:
        try:
            self.save_model(train_step)
            # Flush the freshly written checkpoint to durable storage so an abrupt
            # Colab disconnect cannot discard it before Google Drive syncs.
            _sync = getattr(os, "sync", None)
            if callable(_sync):
                _sync()
        except Exception as exc:  # pragma: no cover - checkpointing must not crash training
            print(f"[masac] periodic checkpoint skipped at step {train_step}: {exc}", flush=True)


def install_masac_runtime_optimizations() -> dict[str, Any]:
    """Patch external MASAC learner methods in-place and return metadata."""

    from ac_discrete import qmix_msac

    cls = qmix_msac.QMIX_PG
    if getattr(cls, "_citylearn_patch_version", None) == PATCH_VERSION:
        return {
            "enabled": True,
            "patch_version": PATCH_VERSION,
            "already_installed": True,
        }

    cls._prepare_citylearn_batch = _prepare_batch
    cls._ensure_citylearn_device = _ensure_device
    cls._citylearn_agent_identity = _agent_identity
    cls._get_inputs = _get_inputs
    cls.init_hidden = _init_hidden
    cls.get_q_values = _get_q_values
    cls.get_q_values_2 = _get_q_values_2
    cls.train_actor = _train_actor
    cls.train_critic = _train_critic
    cls._citylearn_patch_version = PATCH_VERSION

    return {
        "enabled": True,
        "patch_version": PATCH_VERSION,
        "already_installed": False,
        "changes": [
            "sampled replay batches are tensorized once per update",
            "CUDA batch preload uses auto fallback to CPU after OOM",
            "agent identity matrix is cached per device/dtype/batch",
            "hidden-state allocation is created directly on target device",
            "per-timestep .cuda() calls are removed when batch preload succeeds",
        ],
    }

