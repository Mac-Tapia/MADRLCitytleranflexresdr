"""Train MAAC on CityLearn v3 using the original MAAC backend."""

from __future__ import annotations

import argparse
import time
import traceback

import numpy as np
import torch
from torch.autograd import Variable

from citylearn_v3_training_common import (
    CityLearnMAACVecEnv,
    NoOpLogger,
    add_common_citylearn_args,
    add_external_path,
    citylearn_v3_training_report,
    configure_torch_runtime,
    ensure_project_paths,
    ensure_artifact_layout,
    install_finite_optimizer_step_guard,
    job_counts_as_launcher_complete,
    resolve_output_dir,
    discover_job_resume_plan,
    write_job_resume_manifest,
    start_live_progress_heartbeat,
    stop_live_progress_heartbeat,
    write_minimal_results_json,
    write_training_artifacts,
    write_training_summary,
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    add_common_citylearn_args(parser)
    parser.add_argument("--episodes", default=1, type=int)
    parser.add_argument("--action-bins", default=3, type=int)
    parser.add_argument(
        "--discrete-action-mode",
        default="axis",
        choices=("axis", "shared", "cartesian"),
        help="Discrete CityLearn action table. axis is linear in action dimensions; cartesian is exponential.",
    )
    parser.add_argument(
        "--max-discrete-actions",
        default=512,
        type=int,
        help="Abort before MAAC startup if a discrete agent action space is larger than this.",
    )
    parser.add_argument("--batch-size", default=256, type=int)
    parser.add_argument("--buffer-length", default=50000, type=int)
    parser.add_argument("--steps-per-update", default=1, type=int)
    parser.add_argument("--num-updates", default=1, type=int)
    parser.add_argument("--hidden-size", default=256, type=int)
    parser.add_argument("--attend-heads", default=4, type=int)
    parser.add_argument("--pi-lr", default=3e-4, type=float)
    parser.add_argument("--q-lr", default=1e-3, type=float)
    parser.add_argument("--tau", default=1e-3, type=float)
    parser.add_argument("--gamma", default=0.9999, type=float,
                        help="Discount factor. Use 0.9999 for year-long (8760-step) episodes.")
    parser.add_argument("--reward-scale", default=10.0, type=float)
    parser.add_argument("--torch-threads", default=1, type=int)
    parser.add_argument("--live-heartbeat-seconds", default=30, type=int)
    parser.add_argument(
        "--checkpoint-interval-seconds",
        default=600,
        type=int,
        help=(
            "Wall-clock interval for intra-episode rolling checkpoints "
            "(checkpoint_latest.pt). 0 disables. Episodes are 8760 single-threaded "
            "steps, so this caps how much of a long episode a crash can discard."
        ),
    )
    parser.add_argument("--cuda", action="store_true")
    return parser.parse_args()


def _effective_maac_buffer_length(
    buffer_length: int,
    *,
    target_episodes: int,
    episode_time_steps: int,
) -> int:
    """Cap replay RAM to what a full run needs (50 ep x 8760 = 438k steps)."""
    buffer_length = max(256, int(buffer_length))
    target_episodes = max(1, int(target_episodes))
    episode_time_steps = max(1, int(episode_time_steps))
    run_steps = target_episodes * episode_time_steps
    return min(buffer_length, run_steps + episode_time_steps)


def _save_maac_checkpoint(model, path, *, use_gpu: bool) -> None:
    """Atomic checkpoint write; survives flaky Drive FUSE on Colab."""
    from pathlib import Path as _Path

    dest = _Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    staging = dest.with_suffix(dest.suffix + ".tmp")
    if staging.exists():
        staging.unlink()
    try:
        model.save(staging)
        staging.replace(dest)
    except Exception:
        if staging.exists():
            staging.unlink(missing_ok=True)
        raise
    finally:
        model.prep_rollouts(device="gpu" if use_gpu else "cpu")


def main() -> int:
    args = parse_args()
    ensure_project_paths()
    add_external_path("MAAC")
    # The MAAC repo has top-level ``utils`` and ``algorithms`` names. Remove
    # earlier modules with those names so imports resolve to external/MAAC.
    import sys

    sys.modules.pop("utils", None)
    sys.modules.pop("algorithms", None)
    sys.path[:] = [
        entry for entry in sys.path
        if not entry.replace("\\", "/").rstrip("/").endswith("/uc3m")
    ]
    from algorithms.attention_sac import AttentionSAC
    from utils.buffer import ReplayBuffer

    output_dir = resolve_output_dir(args.output_dir, "maac", args.scenario, args.seed)
    artifact_dirs = ensure_artifact_layout(output_dir)

    target_episodes = int(args.episodes)
    resume_plan = discover_job_resume_plan(
        output_dir,
        algorithm="maac",
        target_episodes=int(args.episodes),
        episode_time_steps=args.episode_time_steps,
        allow_resume=bool(getattr(args, "resume", True)),
    )
    if resume_plan.get("active"):
        args.episodes = int(resume_plan["remaining_episodes"])
        print(
            f"[maac] RESUME ep {resume_plan['completed_episodes']}/{resume_plan['target_episodes']} "
            f"-> {args.episodes} remaining",
            flush=True,
        )
    write_job_resume_manifest(output_dir, resume_plan)

    # Resume offset injected via the adapter constructor (same pattern as HAPPO) so the
    # live-progress/CSV adapter continues from the resumed episode instead of ep1.
    maac_resume_completed = (
        int(resume_plan["completed_episodes"]) if resume_plan.get("active") else 0
    )
    env = CityLearnMAACVecEnv(
        schema_path=args.schema_path,
        scenario=args.scenario,
        seed=args.seed,
        episode_time_steps=args.episode_time_steps,
        action_bins=args.action_bins,
        discrete_action_mode=args.discrete_action_mode,
        algorithm="MAAC",
        live_progress_path=str(output_dir / "live_progress.json"),
        live_progress_interval=args.live_progress_interval,
        trace_record_interval=args.trace_record_interval,
        trace_detail=args.trace_detail,
        normalize_observations=args.normalize_observations,
        resume_completed_episodes=maac_resume_completed,
    )

    logger = NoOpLogger()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    gpu_runtime = configure_torch_runtime(
        torch,
        use_cuda=args.cuda,
        torch_threads=args.torch_threads,
        gpu_profile=args.gpu_profile,
        cuda_memory_fraction=args.cuda_memory_fraction,
    )
    use_gpu = bool(gpu_runtime["cuda_enabled"])

    if env.adapter.n_discrete_actions > int(args.max_discrete_actions):
        raise MemoryError(
            "MAAC discrete action space is too large: "
            f"{env.adapter.n_discrete_actions} > {args.max_discrete_actions}. "
            "Use --discrete-action-mode axis for CityLearn multi-actuator actions, "
            "or reduce action bins."
        )

    model = AttentionSAC.init_from_env(
        env,
        tau=args.tau,
        pi_lr=args.pi_lr,
        q_lr=args.q_lr,
        gamma=args.gamma,
        pol_hidden_dim=args.hidden_size,
        critic_hidden_dim=args.hidden_size,
        attend_heads=args.attend_heads,
        reward_scale=args.reward_scale,
    )
    effective_buffer_length = _effective_maac_buffer_length(
        args.buffer_length,
        target_episodes=target_episodes,
        episode_time_steps=args.episode_time_steps,
    )
    if effective_buffer_length != int(args.buffer_length):
        print(
            f"[maac] buffer-length capped {args.buffer_length} -> {effective_buffer_length} "
            f"(target {target_episodes} ep x {args.episode_time_steps} steps)",
            flush=True,
        )
        args.buffer_length = effective_buffer_length

    if resume_plan.get("active") and resume_plan.get("maac_checkpoint"):
        model = AttentionSAC.init_from_save(str(resume_plan["maac_checkpoint"]), load_critic=True)
        print(f"[maac] Loaded {resume_plan['maac_checkpoint']}", flush=True)
        model.prep_training(device="gpu" if use_gpu else "cpu")
    finite_optimizer_guard = install_finite_optimizer_step_guard(
        [
            {
                "owner": "maac_critic",
                "module": getattr(model, "critic", None),
                "optimizer": getattr(model, "critic_optimizer", None),
            }
        ]
        + [
            {
                "owner": f"maac_agent{agent_index}_policy",
                "module": getattr(agent, "policy", None),
                "optimizer": getattr(agent, "policy_optimizer", None),
            }
            for agent_index, agent in enumerate(getattr(model, "agents", []) or [])
        ],
        output_dir / "data" / "maac_finite_gradient_guard.jsonl",
    )
    maac_start_episode = int(resume_plan.get("maac_start_episode") or 0) if resume_plan.get("active") else 0
    replay_buffer = ReplayBuffer(
        args.buffer_length,
        model.nagents,
        [space.shape[0] for space in env.observation_space],
        [space.n for space in env.action_space],
    )

    t = 0
    report = citylearn_v3_training_report(None)
    artifacts = {}
    hyperparameters = {
        "episodes": args.episodes,
        "episode_length": args.episode_time_steps,
        "action_bins": args.action_bins,
        "discrete_action_mode": args.discrete_action_mode,
        "discrete_action_metadata": env.adapter.discrete_action_metadata,
        "max_discrete_actions": args.max_discrete_actions,
        "n_discrete_actions": env.adapter.n_discrete_actions,
        "batch_size": args.batch_size,
        "buffer_length": args.buffer_length,
        "steps_per_update": args.steps_per_update,
        "num_updates": args.num_updates,
        "hidden_size": args.hidden_size,
        "attend_heads": args.attend_heads,
        "pi_lr": args.pi_lr,
        "q_lr": args.q_lr,
        "tau": args.tau,
        "gamma": args.gamma,
        "reward_scale": args.reward_scale,
        "torch_threads": args.torch_threads,
        "live_progress_interval": args.live_progress_interval,
        "live_heartbeat_seconds": args.live_heartbeat_seconds,
        "cuda": use_gpu,
        "gpu_runtime": gpu_runtime,
        "algorithm_family": "MADRL",
        "critic": "multi-agent attention critic",
        "reward_function": "CityLearnV3MADRLRewardFunction",
        "reward_profile": "MAAC",
        "reward_metadata": env.adapter.reward_metadata,
        "finite_optimizer_step_guard": finite_optimizer_guard,
        "job_resume": resume_plan,
        "maac_start_episode": maac_start_episode,
        "target_episodes": target_episodes,
    }
    heartbeat_stop = None
    heartbeat_thread = None
    run_error: BaseException | None = None
    try:
        heartbeat_stop, heartbeat_thread = start_live_progress_heartbeat(
            env.adapter,
            args.live_heartbeat_seconds,
            active_stage="maac_backend_training",
            initial_stage="maac_backend_starting",
            note="MAAC backend is collecting transitions or updating attention critics and policies.",
        )
        # Per-episode checkpoints already persist progress; additionally salvage and
        # write artifacts on any failure so a late crash never discards real progress.
        ckpt_interval_s = int(getattr(args, "checkpoint_interval_seconds", 0) or 0)
        last_ckpt_time = time.monotonic()
        latest_ckpt_path = artifact_dirs["checkpoints"] / "checkpoint_latest.pt"
        try:
            for episode in range(maac_start_episode, maac_start_episode + args.episodes):
                obs = env.reset()
                model.prep_rollouts(device="gpu" if use_gpu else "cpu")

                for _step in range(args.episode_time_steps):
                    torch_obs = [
                        Variable(torch.Tensor(np.vstack(obs[:, agent_i])), requires_grad=False)
                        for agent_i in range(model.nagents)
                    ]
                    if use_gpu:
                        torch_obs = [item.cuda() for item in torch_obs]

                    torch_agent_actions = model.step(torch_obs, explore=True)
                    agent_actions = [action.data.cpu().numpy() for action in torch_agent_actions]
                    env_actions = [[action[i] for action in agent_actions] for i in range(env.num_envs)]
                    next_obs, rewards, dones, infos = env.step(env_actions)
                    replay_buffer.push(obs, agent_actions, rewards, next_obs, dones)
                    obs = next_obs
                    t += env.num_envs

                    if len(replay_buffer) >= args.batch_size and (t % args.steps_per_update) < env.num_envs:
                        model.prep_training(device="gpu" if use_gpu else "cpu")
                        for _ in range(args.num_updates):
                            sample = replay_buffer.sample(args.batch_size, to_gpu=use_gpu, norm_rews=False)
                            model.update_critic(sample, logger=logger)
                            model.update_policies(sample, logger=logger)
                            model.update_all_targets()
                        model.prep_rollouts(device="gpu" if use_gpu else "cpu")

                    if ckpt_interval_s > 0 and (time.monotonic() - last_ckpt_time) >= ckpt_interval_s:
                        try:
                            _save_maac_checkpoint(model, latest_ckpt_path, use_gpu=use_gpu)
                            last_ckpt_time = time.monotonic()
                        except Exception as ckpt_exc:  # noqa: BLE001 - never abort training on a salvage save
                            print(f"[maac] rolling checkpoint save failed: {ckpt_exc}", flush=True)

                    if np.all(dones):
                        break

                try:
                    _save_maac_checkpoint(
                        model,
                        artifact_dirs["checkpoints"] / f"checkpoint_episode_{episode + 1}.pt",
                        use_gpu=use_gpu,
                    )
                except Exception as ckpt_exc:  # noqa: BLE001 - Drive FUSE must not abort the run
                    print(
                        f"[maac] episode checkpoint save failed (ep {episode + 1}): {ckpt_exc}",
                        flush=True,
                    )
                last_ckpt_time = time.monotonic()
        except Exception as exc:  # noqa: BLE001 - salvage on any training failure
            run_error = exc
            traceback.print_exc()
            print(
                f"[maac] training loop raised {type(exc).__name__}: {exc}. "
                "Salvaging trained model and writing artifacts so progress is not lost.",
                flush=True,
            )
            try:
                torch.cuda.empty_cache()
            except Exception:
                pass

        try:
            model.prep_rollouts(device="cpu")
        except Exception:
            pass
        try:
            env.adapter.write_live_heartbeat(
                stage="maac_backend_finished",
                note="MAAC backend runner finished; writing final artifacts.",
            )
        except Exception:
            pass
        try:
            _save_maac_checkpoint(model, artifact_dirs["checkpoints"] / "model.pt", use_gpu=False)
        except Exception as exc:  # noqa: BLE001 - never let checkpointing abort finalization
            print(f"[maac] final model.save failed: {exc}", flush=True)
        if run_error is not None:
            hyperparameters["run_completed_with_salvage"] = True
            hyperparameters["run_error"] = f"{type(run_error).__name__}: {run_error}"
        try:
            report = citylearn_v3_training_report(env)
        except Exception as exc:  # noqa: BLE001 - keep fallback report
            print(f"[maac] training report failed, using fallback report: {exc}", flush=True)
        try:
            artifacts = write_training_artifacts(
                output_dir=output_dir,
                algorithm="MAAC",
                backend="external/MAAC",
                args=args,
                report=report,
                candidate=env,
                hyperparameters=hyperparameters,
                extra={
                    "episodes": args.episodes,
                    "environment_steps": t,
                },
            )
        except Exception as exc:  # noqa: BLE001 - guarantee a results.json regardless
            print(
                f"[maac] write_training_artifacts failed ({type(exc).__name__}: {exc}); "
                "writing minimal salvage results.json.",
                flush=True,
            )
            write_minimal_results_json(
                output_dir=output_dir,
                algorithm="MAAC",
                backend="external/MAAC",
                args=args,
                hyperparameters=hyperparameters,
                report=report,
                error=exc,
            )
    finally:
        stop_live_progress_heartbeat(heartbeat_stop, heartbeat_thread)
        env.close()

    if run_error is not None:
        hyperparameters["run_completed_with_salvage"] = True
        hyperparameters["run_error"] = f"{type(run_error).__name__}: {run_error}"
    elif not job_counts_as_launcher_complete(output_dir, target_episodes=target_episodes):
        hyperparameters["run_incomplete"] = True

    write_training_summary(
        output_dir,
        {
            "algorithm": "MAAC",
            "algorithm_family": "MADRL",
            "backend": "external/MAAC",
            "scenario": args.scenario,
            "seed": args.seed,
            "episode_time_steps": args.episode_time_steps,
            "episodes": args.episodes,
            "action_bins": args.action_bins,
            "discrete_action_mode": args.discrete_action_mode,
            "discrete_action_metadata": env.adapter.discrete_action_metadata,
            "n_discrete_actions": env.adapter.n_discrete_actions,
            "output_dir": str(output_dir),
            "artifact_layout": artifacts.get("artifact_layout", {}),
            "hyperparameters": hyperparameters,
            "gpu_runtime": gpu_runtime,
            "reward_metadata": env.adapter.reward_metadata,
            "artifacts": artifacts,
            "project_axis_metrics": report["project_axis_metrics"],
            "citylearn_v3_report": report,
        },
    )
    if run_error is not None:
        return 1
    if not job_counts_as_launcher_complete(output_dir, target_episodes=target_episodes):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
