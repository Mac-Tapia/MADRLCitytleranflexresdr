from typing import Any, List, Mapping, Tuple, Union
import numpy as np
from citylearn.building import Building
from citylearn.data import ZERO_DIVISION_PLACEHOLDER
import logging

LOGGER = logging.getLogger()
class RewardFunction:
    r"""Base and default reward function class.

    The default reward is the electricity consumption from the grid at the current time step returned as a negative value.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    **kwargs : dict
        Other keyword arguments for custom reward calculation.
    """

    def __init__(self, env_metadata: Mapping[str, Any], exponent: float = None, **kwargs):
        penalty_coefficient = kwargs.pop('charging_constraint_penalty_coefficient', None)
        self.env_metadata = env_metadata
        self.exponent = exponent
        self.charging_constraint_penalty_coefficient = penalty_coefficient

    @property
    def env_metadata(self) -> Mapping[str, Any]:
        return self._env_metadata

    @env_metadata.setter
    def env_metadata(self, env_metadata: Mapping[str, Any]):
        self._env_metadata = env_metadata

    @property
    def central_agent(self) -> bool:
        """Expect 1 central agent to control all buildings."""

        return self.env_metadata['central_agent']

    @property
    def exponent(self) -> float:
        return self.__exponent

    @exponent.setter
    def exponent(self, exponent: float):
        self.__exponent = 1.0 if exponent is None else exponent

    @property
    def charging_constraint_penalty_coefficient(self) -> float:
        return getattr(self, '_charging_constraint_penalty_coefficient', 1.0)

    @charging_constraint_penalty_coefficient.setter
    def charging_constraint_penalty_coefficient(self, coefficient: float):
        if coefficient is None:
            self._charging_constraint_penalty_coefficient = 1.0
        else:
            self._charging_constraint_penalty_coefficient = float(coefficient)

    def reset(self):
        """Use to reset variables at the start of an episode."""

        pass

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        r"""Calculates reward.

        Parameters
        ----------
        observations: List[Mapping[str, Union[int, float]]]
            List of all building observations at current :py:attr:`citylearn.citylearn.CityLearnEnv.
            time_step` that are got from calling :py:meth:`citylearn.building.Building.observations`.

        Returns
        -------
        reward: List[float]
            Reward for transition to current timestep.
        """

        net_electricity_consumption = [o['net_electricity_consumption'] for o in observations]
        reward_list = [-(max(o, 0)**self.exponent) for o in net_electricity_consumption]

        if self.central_agent:
            reward = [sum(reward_list)]
        else:
            reward = reward_list

        return reward

class MultiBuildingRewardFunction(RewardFunction):
    def __init__(self, env, reward_functions: dict[str, RewardFunction]):
        self.env = env
        self.reward_functions = reward_functions
        super().__init__(env)

    def calculate(self, observations: list[dict]) -> list[float]:
        rewards = []
        for obs, (building_name, rf) in zip(observations, self.reward_functions.items()):
            if rf is None:
                raise ValueError(f"No reward function for building '{building_name}'")

            rewards.append(rf.calculate([obs]))
        return rewards

    def reset(self):
        for rf in self.reward_functions.values():
            rf.reset()

    @property
    def env_metadata(self):
        return self._env_metadata

    @env_metadata.setter
    def env_metadata(self, env_metadata: Mapping[str, Any]):
        self._env_metadata = env_metadata
        for rf in self.reward_functions.values():
            rf.env_metadata = env_metadata


class MARL(RewardFunction):
    """MARL reward function class.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    """

    def __init__(self, env_metadata: Mapping[str, Any]):
        super().__init__(env_metadata)

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        net_electricity_consumption = [o['net_electricity_consumption'] for o in observations]
        district_electricity_consumption = sum(net_electricity_consumption)
        building_electricity_consumption = np.array(net_electricity_consumption, dtype=float)*-1
        reward_list = np.sign(building_electricity_consumption)*0.01*building_electricity_consumption**2*np.nanmax([0, district_electricity_consumption])

        if self.central_agent:
            reward = [reward_list.sum()]
        else:
            reward = reward_list.tolist()

        return reward

class IndependentSACReward(RewardFunction):
    """Recommended for use with the `SAC` controllers.

    Returned reward assumes that the building-agents act independently of each other, without sharing information through the reward.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    """

    def __init__(self, env_metadata: Mapping[str, Any]):
        super().__init__(env_metadata)

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        net_electricity_consumption = [o['net_electricity_consumption'] for o in observations]
        reward_list = [min(v*-1**3, 0) for v in net_electricity_consumption]

        if self.central_agent:
            reward = [sum(reward_list)]
        else:
            reward = reward_list

        return reward

class SolarPenaltyReward(RewardFunction):
    """The reward is designed to minimize electricity consumption and maximize solar generation to charge energy storage systems.

    The reward is calculated for each building, i and summed to provide the agent with a reward that is representative of all the
    building or buildings (in centralized case)it controls. It encourages net-zero energy use by penalizing grid load satisfaction
    when there is energy in the energy storage systems as well as penalizing net export when the energy storage systems are not
    fully charged through the penalty term. There is neither penalty nor reward when the energy storage systems are fully charged
    during net export to the grid. Whereas, when the energy storage systems are charged to capacity and there is net import from the
    grid the penalty is maximized.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    """

    def __init__(self, env_metadata: Mapping[str, Any]):
        super().__init__(env_metadata)

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        reward_list = []

        for o, m in zip(observations, self.env_metadata['buildings']):
            e = o['net_electricity_consumption']
            cc = m['cooling_storage']['capacity']
            hc = m['heating_storage']['capacity']
            dc = m['dhw_storage']['capacity']
            ec = m['electrical_storage']['capacity']
            cs = o.get('cooling_storage_soc', 0.0)
            hs = o.get('heating_storage_soc', 0.0)
            ds = o.get('dhw_storage_soc', 0.0)
            es = o.get('electrical_storage_soc', 0.0)
            reward = 0.0
            reward += -(1.0 + np.sign(e)*cs)*abs(e) if cc > ZERO_DIVISION_PLACEHOLDER else 0.0
            reward += -(1.0 + np.sign(e)*hs)*abs(e) if hc > ZERO_DIVISION_PLACEHOLDER else 0.0
            reward += -(1.0 + np.sign(e)*ds)*abs(e) if dc > ZERO_DIVISION_PLACEHOLDER else 0.0
            reward += -(1.0 + np.sign(e)*es)*abs(e) if ec > ZERO_DIVISION_PLACEHOLDER else 0.0
            reward_list.append(reward)

        if self.central_agent:
            reward = [sum(reward_list)]
        else:
            reward = reward_list

        return reward

class ComfortReward(RewardFunction):
    """Reward for occupant thermal comfort satisfaction.

    The reward is calculated as the negative difference between the setpoint and indoor dry-bulb temperature raised to some exponent
    if outside the comfort band. If within the comfort band, the reward is the negative difference when in cooling mode and temperature
    is below the setpoint or when in heating mode and temperature is above the setpoint. The reward is 0 if within the comfort band
    and above the setpoint in cooling mode or below the setpoint and in heating mode.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    band: float, default: 2.0
        Setpoint comfort band (+/-). If not provided, the comfort band time series defined in the
        building file, or the default time series value of 2.0 is used.
    lower_exponent: float, default = 2.0
        Penalty exponent for when in cooling mode but temperature is above setpoint upper
        boundary or heating mode but temperature is below setpoint lower boundary.
    higher_exponent: float, default = 2.0
        Penalty exponent for when in cooling mode but temperature is below setpoint lower
        boundary or heating mode but temperature is above setpoint upper boundary.
    """

    def __init__(self, env_metadata: Mapping[str, Any], band: float = None, lower_exponent: float = None, higher_exponent: float = None):
        super().__init__(env_metadata)
        self.band = band
        self.lower_exponent = lower_exponent
        self.higher_exponent = higher_exponent

    @property
    def band(self) -> float:
        return self.__band

    @property
    def lower_exponent(self) -> float:
        return self.__lower_exponent

    @property
    def higher_exponent(self) -> float:
        return self.__higher_exponent

    @band.setter
    def band(self, band: float):
        self.__band = band

    @lower_exponent.setter
    def lower_exponent(self, lower_exponent: float):
        self.__lower_exponent = 2.0 if lower_exponent is None else lower_exponent

    @higher_exponent.setter
    def higher_exponent(self, higher_exponent: float):
        self.__higher_exponent = 2.0 if higher_exponent is None else higher_exponent

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        reward_list = []

        for o in observations:
            heating_demand = o.get('heating_demand', 0.0)
            cooling_demand = o.get('cooling_demand', 0.0)
            heating = heating_demand > cooling_demand
            hvac_mode = o['hvac_mode']
            indoor_dry_bulb_temperature = o['indoor_dry_bulb_temperature']

            if hvac_mode in [1, 2]:
                set_point = o['indoor_dry_bulb_temperature_cooling_set_point'] if hvac_mode == 1 else o['indoor_dry_bulb_temperature_heating_set_point']
                band =  self.band if self.band is not None else o['comfort_band']
                lower_bound_comfortable_indoor_dry_bulb_temperature = set_point - band
                upper_bound_comfortable_indoor_dry_bulb_temperature = set_point + band
                delta = abs(indoor_dry_bulb_temperature - set_point)

                if indoor_dry_bulb_temperature < lower_bound_comfortable_indoor_dry_bulb_temperature:
                    exponent = self.lower_exponent if hvac_mode == 2 else self.higher_exponent
                    reward = -(delta**exponent)

                elif lower_bound_comfortable_indoor_dry_bulb_temperature <= indoor_dry_bulb_temperature < set_point:
                    reward = 0.0 if heating else -delta

                elif set_point <= indoor_dry_bulb_temperature <= upper_bound_comfortable_indoor_dry_bulb_temperature:
                    reward = -delta if heating else 0.0

                else:
                    exponent = self.higher_exponent if heating else self.lower_exponent
                    reward = -(delta**exponent)

            else:
                cooling_set_point = o['indoor_dry_bulb_temperature_cooling_set_point']
                heating_set_point = o['indoor_dry_bulb_temperature_heating_set_point']
                band =  self.band if self.band is not None else o['comfort_band']
                lower_bound_comfortable_indoor_dry_bulb_temperature = heating_set_point - band
                upper_bound_comfortable_indoor_dry_bulb_temperature = cooling_set_point + band
                cooling_delta = indoor_dry_bulb_temperature - cooling_set_point
                heating_delta = indoor_dry_bulb_temperature - heating_set_point

                if indoor_dry_bulb_temperature < lower_bound_comfortable_indoor_dry_bulb_temperature:
                    exponent = self.higher_exponent if not heating else self.lower_exponent
                    reward = -(abs(heating_delta)**exponent)

                elif lower_bound_comfortable_indoor_dry_bulb_temperature <= indoor_dry_bulb_temperature < heating_set_point:
                    reward = -(abs(heating_delta))

                elif heating_set_point <= indoor_dry_bulb_temperature <= cooling_set_point:
                    reward = 0.0

                elif cooling_set_point < indoor_dry_bulb_temperature < upper_bound_comfortable_indoor_dry_bulb_temperature:
                    reward = -(abs(cooling_delta))

                else:
                    exponent = self.higher_exponent if heating else self.lower_exponent
                    reward = -(abs(cooling_delta)**exponent)

            reward_list.append(reward)

        if self.central_agent:
            reward = [sum(reward_list)]

        else:
            reward = reward_list

        return reward

class SolarPenaltyAndComfortReward(RewardFunction):
    """Addition of :py:class:`citylearn.reward_function.SolarPenaltyReward` and :py:class:`citylearn.reward_function.ComfortReward`.

    Parameters
    ----------
    env_metadata: Mapping[str, Any]:
        General static information about the environment.
    band: float, default = 2.0
        Setpoint comfort band (+/-). If not provided, the comfort band time series defined in the
        building file, or the default time series value of 2.0 is used.
    lower_exponent: float, default = 2.0
        Penalty exponent for when in cooling mode but temperature is above setpoint upper
        boundary or heating mode but temperature is below setpoint lower boundary.
    higher_exponent: float, default = 3.0
        Penalty exponent for when in cooling mode but temperature is below setpoint lower
        boundary or heating mode but temperature is above setpoint upper boundary.
    coefficients: Tuple, default = (1.0, 1.0)
        Coefficents for `citylearn.reward_function.SolarPenaltyReward` and :py:class:`citylearn.reward_function.ComfortReward` values respectively.
    """

    def __init__(self, env_metadata: Mapping[str, Any], band: float = None, lower_exponent: float = None, higher_exponent: float = None, coefficients: Tuple = None):
        self.__functions: List[RewardFunction] = [
            SolarPenaltyReward(env_metadata),
            ComfortReward(env_metadata, band=band, lower_exponent=lower_exponent, higher_exponent=higher_exponent)
        ]
        super().__init__(env_metadata)
        self.coefficients = coefficients

    @property
    def coefficients(self) -> Tuple:
        return self.__coefficients

    @RewardFunction.env_metadata.setter
    def env_metadata(self, env_metadata: Mapping[str, Any]) -> Mapping[str, Any]:
        RewardFunction.env_metadata.fset(self, env_metadata)

        for f in self.__functions:
            f.env_metadata = self.env_metadata

    @coefficients.setter
    def coefficients(self, coefficients: Tuple):
        coefficients = [1.0]*len(self.__functions) if coefficients is None else coefficients
        assert len(coefficients) == len(self.__functions), f'{type(self).__name__} needs {len(self.__functions)} coefficients.'
        self.__coefficients = coefficients

    def calculate(self, observations: List[Mapping[str, Union[int, float]]]) -> List[float]:
        reward = np.array([f.calculate(observations) for f in self.__functions], dtype='float32')
        reward = reward*np.reshape(self.coefficients, (len(self.coefficients), 1))
        reward = reward.sum(axis=0).tolist()

        return reward


class Electric_Vehicles_Reward_Function(MARL):
    """
    Reward function for electric vehicle charging behavior in V2G settings.
    Only affects EV-related behavior; other building logic comes from the superclass.
    """

    def __init__(self, env_metadata: Mapping[str, Any], weights: Mapping[str, float] = None):
        super().__init__(env_metadata)

        # Default tunable weights for EV-related reward components
        self.weights = weights or {
            "no_car_charging": -5.0,
            "battery_limits": -2.0,
            "soc_impossible": -10.0,
            "soc_under": -5.0,
            "close_soc": 10.0,
            "self_ev_consumption": 5.0,
            "extra_self_production": 5.0,
        }
        self._last_base_reward_total = 0.0
        self._last_penalty_total = 0.0
        self._last_base_rewards_per_building: List[float] = []
        self._last_penalties_per_building: List[float] = []

    def calculate(self, observations: List[Mapping[str, Union[int, float, dict]]]) -> List[float]:
        current_reward = super().calculate(observations)
        reward_list = []
        base_rewards = []
        penalty_values = []

        for i, o in enumerate(observations):
            ev_info = o.get("electric_vehicles_chargers_dict", {})
            if not ev_info:
                reward = 0
            else:
                if self.central_agent:
                    reward_value = current_reward[0] if isinstance(current_reward, list) else current_reward
                    reward = self.calculate_ev_penalty(o, reward_value)
                else:
                    reward = self.calculate_ev_penalty(o, current_reward[i])

            base_rewards.append(reward)
            violation = float(o.get("charging_constraint_violation_kwh", 0.0) or 0.0)
            penalty = violation * self.charging_constraint_penalty_coefficient if violation > 0.0 else 0.0
            penalty_values.append(penalty)
            reward -= penalty

            reward_list.append(reward)

        self._last_base_rewards_per_building = base_rewards
        self._last_penalties_per_building = penalty_values
        total_reward = [sum(reward_list)] if self.central_agent else reward_list
        self._last_base_reward_total = sum(base_rewards) if self.central_agent else base_rewards
        self._last_penalty_total = sum(penalty_values) if self.central_agent else penalty_values
        LOGGER.debug(f"Calculated EV reward: {total_reward}")
        return total_reward

    def calculate_ev_penalty(self, o: Mapping[str, Union[int, float, dict]], current_reward: float) -> float:

        penalty_total = 0.0
        ev_chargers: dict = o.get("electric_vehicles_chargers_dict", {})
        net_energy_before = o.get("net_electricity_consumption", 0)

        # Bounding the multiplier to avoid extreme scaling
        penalty_multiplier = 1.0 / (1.0 + abs(current_reward))

        for charger_id, data in ev_chargers.items():
            contributions = {k: 0.0 for k in self.weights.keys()}

            if not data["connected"]:
                if data["last_charged_kwh"] and abs(data["last_charged_kwh"]) > 0.1:
                    contributions["no_car_charging"] += self.weights["no_car_charging"] * penalty_multiplier
                LOGGER.debug(f"Charger {charger_id} | EV not connected | Contributions: {contributions}")
                continue

            # Extract values
            soc_prev = data.get("previous_battery_soc")
            soc_now = data.get("battery_soc")
            capacity = data.get("battery_capacity")
            min_capacity = data.get("min_capacity")
            last_charged_kwh = data.get("last_charged_kwh", 0)
            if last_charged_kwh is None:
                last_charged_kwh = 0.0
            required_soc = data.get("required_soc")
            hours_until_departure = data.get("hours_until_departure", 0)
            max_charging_power = data.get("max_charging_power", 0)
            max_discharging_power = data.get("max_discharging_power", 0)

            if soc_prev is None or soc_now is None or capacity is None:
                raise ValueError("Something went wrong, this values should not be none")
                continue
            # Battery limits
            current_energy = soc_prev * capacity + last_charged_kwh
            if current_energy > capacity or current_energy < min_capacity:
                contributions["battery_limits"] += self.weights["battery_limits"] * penalty_multiplier

            # SoC penalties/rewards
            if required_soc is not None:
                soc_diff = soc_now - required_soc
                soc_diff_kWh = soc_diff * capacity

                max_possible_charge = max_charging_power * hours_until_departure
                max_possible_discharge = max_discharging_power * hours_until_departure

                if soc_diff_kWh > max_possible_charge:
                    contributions["soc_impossible"] += self.weights["soc_impossible"] * penalty_multiplier

                if hours_until_departure == 0:
                    if -0.25 < soc_diff <= -0.10:
                        contributions["soc_under"] += 2 * self.weights["soc_under"] * penalty_multiplier
                    elif soc_diff <= -0.25:
                        contributions["soc_under"] += -abs(self.weights["soc_under"] ** 2) * penalty_multiplier
                    elif -0.10 < soc_diff <= 0.10:
                        contributions["close_soc"] += self.weights["close_soc"] * penalty_multiplier

                if abs(soc_diff_kWh) <= max(max_possible_charge, max_possible_discharge):
                    reward_multiplier = 1.0 / (hours_until_departure + 0.1)
                    contributions["close_soc"] += self.weights["close_soc"] * penalty_multiplier * reward_multiplier

            # Self-production reward
            if last_charged_kwh > 0 and net_energy_before < 0:
                contributions["extra_self_production"] += self.weights["extra_self_production"] * penalty_multiplier
            elif last_charged_kwh < 0 and net_energy_before < 0:
                contributions["extra_self_production"] += -0.5 * self.weights["extra_self_production"] * penalty_multiplier

            # Self-consumption reward
            if last_charged_kwh < 0 and net_energy_before > 0:
                contributions["self_ev_consumption"] += self.weights["self_ev_consumption"] * penalty_multiplier
            elif last_charged_kwh > 0 and net_energy_before > 0:
                contributions["self_ev_consumption"] += -0.5 * self.weights["self_ev_consumption"] * penalty_multiplier

            LOGGER.debug(f"Charger {charger_id} | Contributions: {contributions}")
            penalty_total += sum(contributions.values())

        return penalty_total


CITYLEARN_V3_HIERARCHY_LEVELS = {
    "primary": 0.60,
    "secondary": 0.25,
    "residual": 0.15,
}

# Compensatory hierarchy: the primary objective has a strict majority of the
# normalized axis reward, while the other objectives remain active.  This is a
# weighted-sum preference hierarchy, not lexicographic/pre-emptive optimization.
# The cyclic order is balanced: every axis receives each hierarchy level once
# across E1/E2/E3, so no thesis objective has greater aggregate exposure.
CITYLEARN_V3_AXIS_PRIORITY_ORDER = {
    "E1": ("flex", "cost", "carbon"),
    "E2": ("carbon", "flex", "cost"),
    "E3": ("cost", "carbon", "flex"),
}


def _build_hierarchical_axis_reward_weights() -> Mapping[str, Mapping[str, float]]:
    axes = {"flex", "carbon", "cost"}
    levels = CITYLEARN_V3_HIERARCHY_LEVELS

    if not levels["primary"] > levels["secondary"] > levels["residual"] > 0.0:
        raise ValueError("CityLearn v3 hierarchy must satisfy primary > secondary > residual > 0")
    if levels["primary"] <= levels["secondary"] + levels["residual"]:
        raise ValueError("CityLearn v3 primary hierarchy weight must exceed the non-primary sum")
    if not np.isclose(sum(levels.values()), 1.0, atol=1.0e-12):
        raise ValueError("CityLearn v3 hierarchy levels must sum to 1.0")

    weights = {}
    for scenario, order in CITYLEARN_V3_AXIS_PRIORITY_ORDER.items():
        if len(order) != 3 or set(order) != axes:
            raise ValueError(f"Invalid CityLearn v3 axis priority order for {scenario}: {order}")
        weights[scenario] = {
            order[0]: levels["primary"],
            order[1]: levels["secondary"],
            order[2]: levels["residual"],
        }

    for axis in axes:
        assigned = sorted(weights[scenario][axis] for scenario in weights)
        if not np.allclose(assigned, sorted(levels.values()), atol=1.0e-12):
            raise ValueError(f"CityLearn v3 hierarchy is not cyclically balanced for axis {axis}")

    return weights


CITYLEARN_V3_AXIS_REWARD_WEIGHTS = _build_hierarchical_axis_reward_weights()


CITYLEARN_V3_MADRL_REWARD_PROFILES = {
    # v4 — unified_comparable_v4:
    # · bess_cycle_weight=0.10: penaliza ciclado excesivo de BESS por paso (Wan et al., 2022;
    #   Perez et al., 2021). Previene oscilación carga/descarga que acumula degradación
    #   sin beneficio estratégico, observada en MAAC (×79 throughput vs MATD3).
    # · ev_urgency_hours 4→8 h: amplía ventana de urgencia EV para dar señal de gradiente
    #   más temprana a políticas con entropía (MASAC, MAAC) antes de la salida del vehículo
    #   (Pinto et al., 2022; Montoya-Martínez et al., 2023).
    # · ev_departure_deficit_weight 0.55→0.70: refuerza penalización en paso de salida.
    # · ev_idle_deficit_weight 0.15→0.25: penaliza inactividad dentro de ventana urgente.
    "HAPPO": {
        "profile_name": "happo_unified_comparable_v4",
        "axis_weight_multipliers": {"flex": 1.00, "carbon": 1.00, "cost": 1.00},
        "team_reward_ratio": 0.70,
        "ev_weight": 0.25,
        "reward_scale": 1.00,
        "ramp_weight": 0.35,
        "peak_weight": 0.45,
        "bess_cycle_weight": 0.10,
        "bess_cycle_scale": 0.05,
        "ev_soc_tolerance": 0.05,
        "ev_soc_critical_deficit": 0.25,
        "ev_urgency_hours": 8.0,
        "ev_departure_deficit_weight": 0.70,
        "ev_urgency_deficit_weight": 0.30,
        "ev_idle_deficit_weight": 0.25,
    },
    "MASAC": {
        "profile_name": "masac_unified_comparable_v4",
        "axis_weight_multipliers": {"flex": 1.00, "carbon": 1.00, "cost": 1.00},
        "team_reward_ratio": 0.70,
        "ev_weight": 0.25,
        "reward_scale": 1.00,
        "ramp_weight": 0.35,
        "peak_weight": 0.45,
        "bess_cycle_weight": 0.10,
        "bess_cycle_scale": 0.05,
        "ev_soc_tolerance": 0.05,
        "ev_soc_critical_deficit": 0.25,
        "ev_urgency_hours": 8.0,
        "ev_departure_deficit_weight": 0.70,
        "ev_urgency_deficit_weight": 0.30,
        "ev_idle_deficit_weight": 0.25,
    },
    "MATD3": {
        "profile_name": "matd3_unified_comparable_v4",
        "axis_weight_multipliers": {"flex": 1.00, "carbon": 1.00, "cost": 1.00},
        "team_reward_ratio": 0.70,
        "ev_weight": 0.25,
        "reward_scale": 1.00,
        "ramp_weight": 0.35,
        "peak_weight": 0.45,
        "bess_cycle_weight": 0.10,
        "bess_cycle_scale": 0.05,
        "ev_soc_tolerance": 0.05,
        "ev_soc_critical_deficit": 0.25,
        "ev_urgency_hours": 8.0,
        "ev_departure_deficit_weight": 0.70,
        "ev_urgency_deficit_weight": 0.30,
        "ev_idle_deficit_weight": 0.25,
    },
    "MAAC": {
        "profile_name": "maac_unified_comparable_v4",
        "axis_weight_multipliers": {"flex": 1.00, "carbon": 1.00, "cost": 1.00},
        "team_reward_ratio": 0.70,
        "ev_weight": 0.25,
        "reward_scale": 1.00,
        "ramp_weight": 0.35,
        "peak_weight": 0.45,
        "bess_cycle_weight": 0.10,
        "bess_cycle_scale": 0.05,
        "ev_soc_tolerance": 0.05,
        "ev_soc_critical_deficit": 0.25,
        "ev_urgency_hours": 8.0,
        "ev_departure_deficit_weight": 0.70,
        "ev_urgency_deficit_weight": 0.30,
        "ev_idle_deficit_weight": 0.25,
    },
    "MADRL": {
        "profile_name": "generic_citylearn_v3_madrl_v4",
        "axis_weight_multipliers": {"flex": 1.00, "carbon": 1.00, "cost": 1.00},
        "team_reward_ratio": 0.70,
        "ev_weight": 0.25,
        "reward_scale": 1.00,
        "ramp_weight": 0.35,
        "peak_weight": 0.45,
        "bess_cycle_weight": 0.10,
        "bess_cycle_scale": 0.05,
        "ev_soc_tolerance": 0.05,
        "ev_soc_critical_deficit": 0.25,
        "ev_urgency_hours": 8.0,
        "ev_departure_deficit_weight": 0.70,
        "ev_urgency_deficit_weight": 0.30,
        "ev_idle_deficit_weight": 0.25,
    },
}


class CityLearnV3MADRLRewardFunction(Electric_Vehicles_Reward_Function):
    """CityLearn v3 thesis reward for MADRL training.

    The original CityLearn v2 schema keeps the EV-aware MARL reward for
    backward compatibility. This reward is used only by the v3 MADRL adapters
    and exposes explicit axis weights for the thesis objectives plus a separate
    profile for each MADRL backend.
    """

    def __init__(
        self,
        env_metadata: Mapping[str, Any],
        algorithm: str = None,
        scenario: str = None,
        axis_weights: Mapping[str, float] = None,
        profile: Mapping[str, Any] = None,
        ev_weights: Mapping[str, float] = None,
        price_reference: float = 0.20,
        carbon_reference: float = 0.35,
    ):
        super().__init__(env_metadata, weights=ev_weights)
        self.algorithm = str(algorithm or "MADRL").upper()
        self.scenario = str(scenario or "E1").upper()
        self.price_reference = float(price_reference)
        self.carbon_reference = float(carbon_reference)
        self.profile = self._build_profile(profile)
        self.axis_weights = self._build_axis_weights(axis_weights)
        self._last_district_import = None
        self._last_component_breakdown = {}
        self._last_bess_socs: dict = {}

    def reset(self):
        self._last_district_import = None
        self._last_component_breakdown = {}
        self._last_bess_socs = {}

    @property
    def metadata(self) -> Mapping[str, Any]:
        return {
            "function": self.__class__.__name__,
            "algorithm": self.algorithm,
            "scenario": self.scenario,
            "axis_weights": dict(self.axis_weights),
            "weighting_method": "compensatory_hierarchical_weighted_sum",
            "hierarchy_levels": dict(CITYLEARN_V3_HIERARCHY_LEVELS),
            "axis_priority_order": list(CITYLEARN_V3_AXIS_PRIORITY_ORDER.get(self.scenario, ())),
            "profile": dict(self.profile),
            "base_reward": "CityLearnV3MADRLRewardFunction",
            "not_using_marl_base_weights": True,
        }

    def _build_profile(self, profile: Mapping[str, Any] = None) -> Mapping[str, Any]:
        base = dict(
            CITYLEARN_V3_MADRL_REWARD_PROFILES.get(
                self.algorithm,
                CITYLEARN_V3_MADRL_REWARD_PROFILES["MADRL"],
            )
        )
        base["axis_weight_multipliers"] = dict(base.get("axis_weight_multipliers", {}))

        if profile:
            for key, value in profile.items():
                if key == "axis_weight_multipliers":
                    merged = dict(base.get("axis_weight_multipliers", {}))
                    merged.update(dict(value))
                    base[key] = merged
                else:
                    base[key] = value

        return base

    def _build_axis_weights(self, axis_weights: Mapping[str, float] = None) -> Mapping[str, float]:
        raw_weights = dict(
            axis_weights
            or CITYLEARN_V3_AXIS_REWARD_WEIGHTS.get(
                self.scenario,
                {"flex": 1.0 / 3.0, "carbon": 1.0 / 3.0, "cost": 1.0 / 3.0},
            )
        )
        multipliers = dict(self.profile.get("axis_weight_multipliers", {}))
        weighted = {
            key: max(0.0, float(raw_weights.get(key, 0.0)) * float(multipliers.get(key, 1.0)))
            for key in ("flex", "carbon", "cost")
        }
        total = sum(weighted.values())

        if total <= ZERO_DIVISION_PLACEHOLDER:
            return {"flex": 1.0 / 3.0, "carbon": 1.0 / 3.0, "cost": 1.0 / 3.0}

        return {key: value / total for key, value in weighted.items()}

    @staticmethod
    def _safe_float(value: Any, default: float = 0.0) -> float:
        try:
            output = float(value)
        except (TypeError, ValueError):
            return default

        return output if np.isfinite(output) else default

    @staticmethod
    def _soft(value: float, scale: float) -> float:
        scale = max(float(scale), ZERO_DIVISION_PLACEHOLDER)
        return float(np.tanh(max(float(value), 0.0) / scale))

    @staticmethod
    def _mean_soc(observation: Mapping[str, Union[int, float, dict]], names: Tuple[str, ...]) -> float:
        values = []

        for name in names:
            value = CityLearnV3MADRLRewardFunction._safe_float(observation.get(name), default=np.nan)

            if np.isfinite(value):
                values.append(np.clip(value, 0.0, 1.0))

        return 0.0 if not values else float(np.mean(values))

    def _ev_term(self, observation: Mapping[str, Union[int, float, dict]]) -> float:
        if not observation.get("electric_vehicles_chargers_dict", {}):
            return 0.0

        violation = self._safe_float(observation.get("charging_constraint_violation_kwh"), 0.0)
        ev_raw = self.calculate_ev_penalty(observation, current_reward=0.0)
        ev_raw -= max(0.0, violation) * self.charging_constraint_penalty_coefficient
        # Acotar a [-1, 1] para equiparar escala con flex/carbon/cost (que ya usan
        # _soft()/tanh). El divisor 10.0 corresponde al peso close_soc del framework
        # base: con 1 cargador activo ev_raw ∈ [-10, +10] → tanh(ev_raw/10) ∈ (-1, 1).
        base_term = float(np.tanh(ev_raw / 10.0))
        service_constraint = self._ev_service_constraint_term(observation)
        return float(np.clip(base_term + service_constraint, -1.0, 1.0))

    def _ev_service_constraint_term(self, observation: Mapping[str, Union[int, float, dict]]) -> float:
        """Penalize unmet EV service obligations independently of energy KPIs."""

        ev_chargers: Mapping[str, Mapping[str, Any]] = observation.get("electric_vehicles_chargers_dict", {})
        if not ev_chargers:
            return 0.0

        tolerance = max(self._safe_float(self.profile.get("ev_soc_tolerance"), 0.05), ZERO_DIVISION_PLACEHOLDER)
        critical_deficit = max(
            self._safe_float(self.profile.get("ev_soc_critical_deficit"), 0.25),
            tolerance,
        )
        urgency_hours = max(self._safe_float(self.profile.get("ev_urgency_hours"), 4.0), 0.0)
        departure_weight = max(self._safe_float(self.profile.get("ev_departure_deficit_weight"), 0.55), 0.0)
        urgency_weight = max(self._safe_float(self.profile.get("ev_urgency_deficit_weight"), 0.30), 0.0)
        idle_weight = max(self._safe_float(self.profile.get("ev_idle_deficit_weight"), 0.15), 0.0)

        departure_terms = []
        urgency_terms = []
        idle_terms = []

        for data in ev_chargers.values():
            if not data.get("connected", False):
                continue

            soc_now = self._safe_float(data.get("battery_soc"), default=np.nan)
            required_soc = self._safe_float(data.get("required_soc"), default=np.nan)
            if not np.isfinite(soc_now) or not np.isfinite(required_soc):
                continue

            deficit = max(0.0, required_soc - soc_now)
            if deficit <= tolerance:
                continue

            hours_until_departure = max(self._safe_float(data.get("hours_until_departure"), 0.0), 0.0)
            last_charged_kwh = self._safe_float(data.get("last_charged_kwh"), 0.0)
            deficit_ratio = float(np.clip((deficit - tolerance) / critical_deficit, 0.0, 1.0))
            urgency_factor = 0.0

            if hours_until_departure <= urgency_hours:
                urgency_factor = float((urgency_hours - hours_until_departure + 1.0) / (urgency_hours + 1.0))
                urgency_terms.append(deficit_ratio * urgency_factor)

            if hours_until_departure <= ZERO_DIVISION_PLACEHOLDER:
                departure_terms.append(deficit_ratio)

            if urgency_factor > 0.0 and last_charged_kwh <= ZERO_DIVISION_PLACEHOLDER:
                idle_terms.append(deficit_ratio * urgency_factor)

        def mean_or_zero(values: List[float]) -> float:
            return 0.0 if not values else float(np.mean(values))

        penalty = (
            departure_weight * mean_or_zero(departure_terms)
            + urgency_weight * mean_or_zero(urgency_terms)
            + idle_weight * mean_or_zero(idle_terms)
        )
        return -float(np.clip(penalty, 0.0, 1.0))

    def calculate(self, observations: List[Mapping[str, Union[int, float, dict]]]) -> List[float]:
        net_values = [self._safe_float(o.get("net_electricity_consumption")) for o in observations]
        imports = [max(value, 0.0) for value in net_values]
        exports = [max(-value, 0.0) for value in net_values]
        district_import = float(np.sum(imports))
        district_ramp = 0.0 if self._last_district_import is None else abs(district_import - self._last_district_import)
        self._last_district_import = district_import
        n_buildings = max(len(observations), 1)
        ramp_share = district_ramp / n_buildings
        peak_share = district_import / n_buildings

        peak_weight = float(self.profile.get("peak_weight", 0.45))
        ramp_weight = float(self.profile.get("ramp_weight", 0.35))
        ev_weight = float(self.profile.get("ev_weight", 0.25))
        reward_scale = float(self.profile.get("reward_scale", 1.0))
        team_reward_ratio = float(np.clip(self.profile.get("team_reward_ratio", 0.70), 0.0, 1.0))
        individual_ratio = 1.0 - team_reward_ratio
        # BESS cycling penalty (v4): penaliza |ΔSOC| por paso para inhibir oscilación
        # carga/descarga sin beneficio estratégico (Wan et al., 2022; Perez et al., 2021).
        bess_cycle_weight = float(self.profile.get("bess_cycle_weight", 0.0))
        bess_cycle_scale = max(float(self.profile.get("bess_cycle_scale", 0.05)), ZERO_DIVISION_PLACEHOLDER)
        rewards = []
        components = []

        for i, (observation, net_value, import_value, export_value) in enumerate(zip(observations, net_values, imports, exports)):
            price = max(self._safe_float(observation.get("electricity_pricing")), 0.0)
            carbon = max(self._safe_float(observation.get("carbon_intensity")), 0.0)
            price_norm = price / (price + self.price_reference) if price > 0.0 else 0.0
            carbon_norm = carbon / (carbon + self.carbon_reference) if carbon > 0.0 else 0.0
            storage_soc = self._mean_soc(
                observation,
                ("electrical_storage_soc", "cooling_storage_soc", "heating_storage_soc", "dhw_storage_soc"),
            )
            storage_headroom = max(0.0, 1.0 - storage_soc)

            flex_penalty = (
                peak_weight * self._soft(peak_share, 25.0)
                + ramp_weight * self._soft(ramp_share, 15.0)
                + 0.15 * self._soft(export_value * (1.0 + storage_headroom), 20.0)
                + 0.10 * self._soft(import_value * storage_soc, 20.0)
            )
            carbon_penalty = self._soft(import_value * (0.25 + carbon_norm), 20.0)
            carbon_credit = 0.05 * self._soft(export_value * carbon_norm, 20.0)
            cost_penalty = self._soft(import_value * (0.25 + price_norm), 20.0)
            cost_credit = 0.08 * self._soft(export_value * price_norm, 20.0)
            flex_component = -flex_penalty
            carbon_component = -carbon_penalty + carbon_credit
            cost_component = -cost_penalty + cost_credit
            ev_component = ev_weight * self._ev_term(observation)

            # Penalización BESS por ciclado excesivo: -w·tanh(|soc_t - soc_{t-1}| / scale)
            bess_cycle_component = 0.0
            if bess_cycle_weight > ZERO_DIVISION_PLACEHOLDER:
                bess_soc_now = self._safe_float(observation.get("electrical_storage_soc"), default=np.nan)
                bess_soc_prev = self._last_bess_socs.get(i, np.nan)
                if np.isfinite(bess_soc_now) and np.isfinite(bess_soc_prev):
                    bess_delta = abs(bess_soc_now - bess_soc_prev)
                    bess_cycle_component = -bess_cycle_weight * self._soft(bess_delta, bess_cycle_scale)
                if np.isfinite(bess_soc_now):
                    self._last_bess_socs[i] = bess_soc_now

            axis_contributions = {
                "flex": self.axis_weights["flex"] * flex_component,
                "carbon": self.axis_weights["carbon"] * carbon_component,
                "cost": self.axis_weights["cost"] * cost_component,
            }
            axis_absolute_total = float(sum(abs(value) for value in axis_contributions.values()))
            axis_effective_shares = {
                key: (
                    abs(value) / axis_absolute_total
                    if axis_absolute_total > ZERO_DIVISION_PLACEHOLDER
                    else 0.0
                )
                for key, value in axis_contributions.items()
            }

            scalar_reward = reward_scale * (
                sum(axis_contributions.values())
                + ev_component
                + bess_cycle_component
            )
            rewards.append(float(scalar_reward))
            components.append({
                "net": net_value,
                "flex": flex_component,
                "carbon": carbon_component,
                "cost": cost_component,
                "weighted_flex": axis_contributions["flex"],
                "weighted_carbon": axis_contributions["carbon"],
                "weighted_cost": axis_contributions["cost"],
                "effective_flex_share": axis_effective_shares["flex"],
                "effective_carbon_share": axis_effective_shares["carbon"],
                "effective_cost_share": axis_effective_shares["cost"],
                "ev": ev_component,
                "bess_cycle": bess_cycle_component,
            })

        team_reward = float(np.mean(rewards)) if rewards else 0.0
        mixed_rewards = [individual_ratio * value + team_reward_ratio * team_reward for value in rewards]
        self._last_component_breakdown = {
            "algorithm": self.algorithm,
            "scenario": self.scenario,
            "axis_weights": dict(self.axis_weights),
            "weighting_method": "compensatory_hierarchical_weighted_sum",
            "effective_share_scope": "absolute_weighted_axis_terms_excluding_ev_and_bess",
            "profile_name": self.profile.get("profile_name"),
            "district_import": district_import,
            "district_ramp": district_ramp,
            "team_reward": team_reward,
            "components": components,
        }

        if self.central_agent:
            return [float(np.sum(mixed_rewards))]

        return [float(value) for value in mixed_rewards]
